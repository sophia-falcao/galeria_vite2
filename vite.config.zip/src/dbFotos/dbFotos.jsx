
export const Fotos = [
    {
        id:1,
        img: "https://cdn.pixabay.com/photo/2014/11/25/16/32/drop-545377_640.jpg"
    },
    {
        id:2,
        img: "https://cdn.pixabay.com/photo/2017/12/11/15/34/lion-3012515_640.jpg"
    },
    {
        id: 3,
        img: "https://cdn.pixabay.com/photo/2014/03/23/09/38/swan-293157_640.jpg"
    },
    {
        id: 4,
        img: "https://cdn.pixabay.com/photo/2017/01/08/19/30/rio-de-janeiro-1963744_1280.jpg"
    },
    {
        id: 5,
        img: "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_1280.jpg"
    },
    {
        id: 7,
        img: "https://cdn.pixabay.com/photo/2015/10/08/15/59/wallpaper-978000_640.jpg"
    },
    {
        id: 8,
        img: "https://cdn.pixabay.com/photo/2023/07/10/18/59/bird-8118926_1280.jpg"
    },
    {
        id: 9,
        img: "https://cdn.pixabay.com/photo/2016/04/06/01/32/red-fox-1310826_1280.jpg"
    }
]