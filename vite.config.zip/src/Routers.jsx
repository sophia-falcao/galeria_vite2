import {BrowserRouter, Routes, Route} from 'react-router-dom'
import { Home } from './pages/Home/Home'
import { Register } from './pages/Cadastro/Register'
import {Login} from './pages/Login/Login'
import { Footer } from './components/Footer'

import { Galeria } from './pages/galeria/galeria'
import { NavBar } from './components/NavBar'






function Routers() {


  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />}/>
            <Route path='/register' element={<Register/>} />
            <Route path='/login' element={<Login/>} />
            <Route path='/galeria' element={<Galeria />} />
        </Routes>
        <Footer />
      </BrowserRouter>

    </div>
  )
}

export default Routers
