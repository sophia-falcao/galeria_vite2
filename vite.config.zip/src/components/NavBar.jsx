import styles from './NavBar.module.css'
import { NavLink } from 'react-router-dom'


export function NavBar(){

    return(
        
        <header>
            <nav className={styles.navbar}>
                <NavLink to='/'> 
                 SFC
                </NavLink>


                    <ul className={styles.links_list}>
                        <li>
                            <NavLink  to='/login' > Login</NavLink> 
                        </li>
                        <li> 
                            <NavLink to='/register' >Cadastre-se</NavLink> 
                        </li>
                        
                    </ul>



             
            </nav>
        </header>
    )
}