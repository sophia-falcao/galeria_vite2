import styles from './Footer.module.css'


export function Footer(){

    return(
        <footer className={styles.footer}>
            <h3>Compartilhe e guarde as suas melhore fotos!</h3>
            <p>Galeria &copy; 2023</p>
        </footer>
    )
}