import {NavLink} from 'react-router-dom'

import styles  from './NavBarGaleria.module.css'

export function NavBarGaleria(){

    return(
        
        <header>
            <nav className={styles.navbar}>
                <NavLink> 
                Minha galeria SFC
                </NavLink>


                    <ul className={styles.links_list}>
                        <li>
                            <NavLink > Home </NavLink>
                        </li>
                        <li>
                            <NavLink  >Adicionar foto</NavLink> 
                        </li>
                        <li> 
                            <NavLink >Criar album</NavLink> 
                        </li>
                        <li> 
                            <NavLink to='/'> Sair  </NavLink> 
                        </li>
                    </ul>



             
            </nav>
        </header>
    )
}