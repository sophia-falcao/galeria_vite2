import { NavBar } from '../../components/NavBar'
import styles from './Home.module.css'

import{useNavigate} from 'react-router-dom'


export function Home(){

    const navigate = useNavigate()

    

    function pagLogin(){
        navigate('/login')
        
    }

    
    return(
        
           <div>
             <NavBar /> 
             <main className={styles.container}>
                <div className={styles.container_banner}>
                    <h2>Entre e compartilhe as suas histórias</h2>
                    <button onClick={pagLogin} className={styles.btn_banner}> Entrar </button>
                </div>
                

             </main>

           </div>
       
    )
}   