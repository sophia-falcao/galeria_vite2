import { NavBar } from '../../components/NavBar'
import styles from './Register.module.css'


export function Register(){

    return(
        <div>
            <NavBar />
        <div className={styles.register}>
            <p>Cadastre-se e compartilhe suas melhores fotos! </p>

            <form>
                <label>
                    <span>Nome: </span>
                    <input 
                        type="text" 
                        placeholder="Digite o nome do usuário"
                        required
                    />
                </label>
                <label>
                    <span>E-mail: </span>
                    <input 
                        type="email" 
                        placeholder="Digite o seu email"
                        required
                    />
                </label>
                <label>
                    <span>Senha: </span>
                    <input 
                        type="password" 
                        placeholder="insira a sua senha"
                        required
                    />
                </label>
                <label>
                    <span>Confirmação de senha: </span>
                    <input 
                        type="password" 
                        placeholder="Confirme a sua senha"
                        required
                    />
                </label>

                <button className='btn'>Cadastrar</button>
            </form>
        </div>


        </div>
    )
   
}