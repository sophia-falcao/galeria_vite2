import { Fotos } from '../../dbFotos/dbFotos'
import { useState } from 'react'

import styles from './galeria.module.css'
import { NavBarGaleria } from '../../components/NavBarGaleria'

export function Galeria(){
    const [fotos, setFotos]= useState(Fotos)
    
    return(
        <div>
            <NavBarGaleria />
            <main>
                <section className={styles.container_foto}>
                    {fotos.map(foto => (
                      <div className={styles.card_foto} key={foto.id}> 
                        <img src={foto.img} alt="fotos" />               
                      </div>
                    ))}
                </section>
            </main>

        </div>
    )
}