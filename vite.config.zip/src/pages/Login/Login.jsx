
import { NavBar } from '../../components/NavBar'
import styles from './Login.module.css'
import {useNavigate} from 'react-router-dom'

export function Login(){

    const navigate = useNavigate()


    function handleLogin(e){
       
        navigate('/galeria')  
    }

    return(

        <div>
         <NavBar />
         <div className={styles.login}>
            <p>Entre agora! </p>
            <form onSubmit={handleLogin}>
             <label>
                <span>Email: </span>
                <input 
                    type="email"
                    placeholder='Digite o seu email'
                    required
                />
             </label>

             <label>
                <span>Senha:</span>
                <input 
                    type="password" 
                    placeholder='Insira a sua senha'
                    required
                />
             </label>

             <button className='btn' type='submit'> Entrar </button>
            </form>
         </div>
        </div>
    )
}